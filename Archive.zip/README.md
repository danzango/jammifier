# jammifier
An app to jam with your friends and learn some music theory!
